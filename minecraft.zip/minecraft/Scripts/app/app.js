var app;
(function (app) {
    app.init = function () {
        console.log("app.init");
        app.world.init();
        app.viewModel.init();
        ko.applyBindings(app.viewModel, $("#content")[0]);
    };
})(app || (app = {}));
var app;
(function (app) {
    (function (types) {
        var Item = (function () {
            function Item(name, dependencies) {
                this.imageUrl = "";
                this.name = name;
                this.dependencies = dependencies;
            }
            return Item;
        })();
        types.Item = Item;        
        var Dependency = (function () {
            function Dependency(_buildMatrix) {
                this.buildMatrix = ko.observableArray([
                    ko.observableArray([]), 
                    ko.observableArray([]), 
                    ko.observableArray([])
                ]);
                this.buildList = null;
                this.buildString = null;
                var _this = this;
                for(var i = 0; i < _buildMatrix.length; i++) {
                    var currentRow = _buildMatrix[i];
                    for(var j = 0; j < currentRow.length; j++) {
                        var currentItem = currentRow[j];
                        this.buildMatrix()[i].push(currentItem);
                    }
                }
                this.buildList = ko.computed(function () {
                    var requirements = {
                    };
                    var observedBuildMatrix = ko.toJS(_this.buildMatrix());
                    for(var i = 0; i < observedBuildMatrix.length; i++) {
                        var thisRow = observedBuildMatrix[i];
                        for(var j = 0; j < thisRow.length; j++) {
                            var thisItemName = thisRow[j];
                            if(thisItemName === null || thisItemName === "") {
                                continue;
                            }
                            requirements[thisItemName] = (requirements[thisItemName] || 0) + 1;
                        }
                    }
                    return requirements;
                });
                this.buildString = ko.computed(function () {
                    return ko.toJSON(_this.buildMatrix);
                });
            }
            Dependency.prototype.getBuildList = function () {
                return this.buildList();
            };
            Dependency.prototype.getBuildString = function () {
                return this.buildString();
            };
            return Dependency;
        })();
        types.Dependency = Dependency;        
        var InventoryItem = (function () {
            function InventoryItem(item, qty) {
                this.qty = ko.observable(0);
                this.item = null;
                var _this = this;
                this.qty.subscribe(function (newQty) {
                    console.log(_this.item.name, "qty changed to", newQty);
                });
                this.item = item;
                this.qty(qty);
            }
            return InventoryItem;
        })();
        types.InventoryItem = InventoryItem;        
    })(app.types || (app.types = {}));
    var types = app.types;
})(app || (app = {}));
var app;
(function (app) {
    (function (world) {
        world.itemNames = {
            stone: "stone",
            ironIngot: "ironIngot",
            stick: "stick",
            ironShovel: "ironShovel",
            ironPickaxe: "ironPickaxe",
            ironAxe: "ironAxe",
            stoneShovel: "stoneShovel",
            stonePickaxe: "stonePickaxe",
            stoneAxe: "stoneAxe"
        };
        world.allItems = {
        };
        world.init = function () {
            var elementalTypes = [
                world.itemNames.stone, 
                world.itemNames.ironIngot, 
                world.itemNames.stick
            ];
            for(var i = 0; i < elementalTypes.length; i++) {
                var elementalName = elementalTypes[i];
                world.allItems[elementalName] = new app.types.Item(elementalName, null);
            }
            var addItem = function (itemName, _buildMatrix) {
                world.allItems[itemName] = new app.types.Item(itemName, new app.types.Dependency(_buildMatrix));
            };
            addItem(world.itemNames.stoneShovel, [
                [
                    null, 
                    world.itemNames.stone, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ]
            ]);
            addItem(world.itemNames.ironShovel, [
                [
                    null, 
                    world.itemNames.ironIngot, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ]
            ]);
            addItem(world.itemNames.stonePickaxe, [
                [
                    world.itemNames.stone, 
                    world.itemNames.stone, 
                    world.itemNames.stone
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ]
            ]);
            addItem(world.itemNames.ironPickaxe, [
                [
                    world.itemNames.ironIngot, 
                    world.itemNames.ironIngot, 
                    world.itemNames.ironIngot
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ], 
                [
                    null, 
                    world.itemNames.stick, 
                    null
                ]
            ]);
            addItem = null;
        };
    })(app.world || (app.world = {}));
    var world = app.world;
})(app || (app = {}));
var app;
(function (app) {
    (function (viewModel) {
        viewModel.init = function () {
            console.log("app.viewModel.init");
            addItemToInventory(app.world.itemNames.stone, 1);
            addItemToInventory(app.world.itemNames.ironIngot, 1);
            addItemToInventory(app.world.itemNames.stick, 2);
            viewModel.allItemsWithDependencies = ko.computed(function () {
                console.log("computed: allItemsWithDependencies");
                var results = [];
                for(var itemName in app.world.allItems) {
                    if(!app.world.allItems.hasOwnProperty(itemName)) {
                        continue;
                    }
                    var item = app.world.allItems[itemName];
                    if(item.dependencies === null) {
                        continue;
                    }
                    results.push(item);
                }
                return results;
            });
            viewModel.inventoryLookup = ko.computed(function () {
                console.log("computed: inventoryLookup");
                var currentInventory = viewModel.inventory();
                var inventoryLookupObject = {
                };
                for(var i = 0; i < currentInventory.length; i++) {
                    var currentInventoryItem = currentInventory[i];
                    inventoryLookupObject[currentInventoryItem.item.name] = currentInventoryItem;
                }
                return inventoryLookupObject;
            });
            viewModel.buildableItems = ko.computed(function () {
                console.log("computed: buildableItems");
                var results = [];
                var itemsWithDependencies = viewModel.allItemsWithDependencies();
                var inventoryLookupObject = viewModel.inventoryLookup();
                for(var i = 0; i < itemsWithDependencies.length; i++) {
                    var currentItem = itemsWithDependencies[i];
                    if(canBuildItem(currentItem, inventoryLookupObject) === true) {
                        console.log("can build", currentItem.name);
                        results.push(currentItem);
                    } else {
                        console.log("can't build", currentItem.name);
                    }
                }
                return results;
            });
        };
        viewModel.helloMsg = ko.observable("");
        viewModel.inventory = ko.observableArray([]);
        viewModel.inventoryLookup;
        viewModel.allItemsWithDependencies;
        viewModel.buildableItems;
        var addItemToInventory = function (itemName, qty) {
            viewModel.inventory.push(new app.types.InventoryItem(app.world.allItems[itemName], qty));
        };
        var canBuildItem = function (item, currentInventory) {
            if(item.dependencies === null) {
                throw "items without dependencies (" + item.name + ") should not be built";
            }
            var buildListForItem = item.dependencies.getBuildList();
            for(var requiredItemName in buildListForItem) {
                if(!buildListForItem.hasOwnProperty(requiredItemName)) {
                    continue;
                }
                var requiredQtyToBuildItem = buildListForItem[requiredItemName];
                if(typeof currentInventory[requiredItemName] === "undefined") {
                    return false;
                }
                if(currentInventory[requiredItemName].qty() < requiredQtyToBuildItem) {
                    return false;
                }
            }
            return true;
        };
    })(app.viewModel || (app.viewModel = {}));
    var viewModel = app.viewModel;
})(app || (app = {}));
$(function () {
    app.init();
});
