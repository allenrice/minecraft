/// <reference path="../typings/jquery/jquery.d.ts" />
/// <reference path="../typings/knockout/knockout.d.ts" />




module app {

	export var init = function () {

		console.log("app.init");
		app.world.init();
		app.viewModel.init();

		ko.applyBindings(app.viewModel, $("#content")[0]);

	};
}



module app.types {

	/** represents a single item in the game, includes dependencies, names, etc */
	export class Item {

		public imageUrl: string;
		public name: string;
		public dependencies: Dependency;

		constructor(name: string, dependencies: Dependency) {
			this.imageUrl = "";
			this.name = name;
			this.dependencies = dependencies;
		}
	}

	/** represents what a given item depends on to be crafted */
	export class Dependency {

		/** the actual build matrix to build this item */
		public buildMatrix: KnockoutObservableArray = ko.observableArray([
			ko.observableArray([]),
			ko.observableArray([]),
			ko.observableArray([])
		]);

		/** list representation of the build matrix, has Item name and qty */
		private buildList: KnockoutComputed = null;

		/** gets a strongly typed version of buildList */
		public getBuildList(): { [dependencyName: string]: number; } {
			return this.buildList();
		}

		/** json string representation of the build matrix */
		private buildString: KnockoutComputed = null;

		/** gets a strongly typed version of buildString */
		public getBuildString() : string {
			return this.buildString();
		}


		constructor(_buildMatrix: string[][]) {
			
			// create the computeds here since we will have access to "this" / "_this" when we didn't before
			var _this = this;

			// go through the passed in build matrix and populate the build matrix
			for (var i = 0; i < _buildMatrix.length; i++) {
				var currentRow = _buildMatrix[i];

				// foreach column
				for (var j = 0; j < currentRow.length; j++) {
					var currentItem = currentRow[j];

					// add it to the build matrix
					this.buildMatrix()[i].push(currentItem);
				}
			}

			//#region buildList computed body
			this.buildList = ko.computed(function () {
				
				var requirements: { [dependencyName: string]: number; } = {};

				var observedBuildMatrix = ko.toJS(_this.buildMatrix());
				
				// foreach row
				for (var i = 0; i < observedBuildMatrix.length; i++) {
					var thisRow: KnockoutObservableArray = observedBuildMatrix[i];

					// foreach column
					for (var j = 0; j < thisRow.length; j++) {
						var thisItemName: string = thisRow[j];

						if (thisItemName === null || thisItemName === "") { continue; }

						// add / increment the count of this item in the list
						requirements[thisItemName] = (requirements[thisItemName] || 0) + 1;
					}
				}

				return requirements;
			});
			//#endregion

			//#region buildString computed body
			this.buildString = ko.computed(function () {
				return ko.toJSON(_this.buildMatrix);
			});
			//#endregion


		}

	}

	/** represents an item in the inventory, in inventory it has qty and will probably have more later on */
	export class InventoryItem {
		
		public qty: KnockoutObservableNumber = ko.observable(0);
		public item: Item = null;

		constructor(item: Item, qty: number) {
			var _this = this;

			this.qty.subscribe(function (newQty: number) {
				console.log(_this.item.name, "qty changed to", newQty);
			});

			this.item = item;
			this.qty(qty);
			

		}
	}
}

module app.world {

	/** all of the items in the world are listed here. this is used to access items within allitems */
	export var itemNames = {
		stone: "stone",
		ironIngot: "ironIngot",
		stick: "stick",
		ironShovel: "ironShovel",
		ironPickaxe: "ironPickaxe",
		ironAxe: "ironAxe",
		stoneShovel: "stoneShovel",
		stonePickaxe: "stonePickaxe",
		stoneAxe: "stoneAxe"
	};

	/** all the items in the world are stored / defined here, to look them up, see: itemNames */
	export var allItems: { [itemName: string]: app.types.Item; } = {};

	export var init = function () {

		// build a list of all the base / elemental types that have no dependencies
		var elementalTypes: string[] = [
			itemNames.stone,
			itemNames.ironIngot,
			itemNames.stick
		];

		// build all the actual items for these elemental types and add it to the all items object
		for (var i = 0; i < elementalTypes.length; i++) {
			var elementalName : string = elementalTypes[i];
			// elementals dont have a dependency so we can consolidate the calls to init these guys
			allItems[elementalName] = new app.types.Item(elementalName, null);
		}

		// this is just a helper to cut down on repetitive code, given an item name and a build matrix, it will add a new Item with a proper dependency to the all items list
		var addItem = function (itemName: string, _buildMatrix: string[][]) {
			allItems[itemName] = new app.types.Item(itemName, new app.types.Dependency(_buildMatrix));
		};

		//#region go through and build all of the complex types
		addItem(itemNames.stoneShovel, [
			[null, itemNames.stone, null],
			[null, itemNames.stick, null],
			[null, itemNames.stick, null]
		]);

		addItem(itemNames.ironShovel, [
			[null, itemNames.ironIngot, null],
			[null, itemNames.stick, null],
			[null, itemNames.stick, null]
		]);

		addItem(itemNames.stonePickaxe, [
			[itemNames.stone, itemNames.stone, itemNames.stone],
			[null, itemNames.stick, null],
			[null, itemNames.stick, null]
		]);

		addItem(itemNames.ironPickaxe, [
			[itemNames.ironIngot, itemNames.ironIngot, itemNames.ironIngot],
			[null, itemNames.stick, null],
			[null, itemNames.stick, null]
		]);

		addItem = null;

		//#endregion
		

	}
}

module app.viewModel {

	export var init = function () {
		console.log("app.viewModel.init");

		addItemToInventory(app.world.itemNames.stone, 1);
		addItemToInventory(app.world.itemNames.ironIngot, 1);
		addItemToInventory(app.world.itemNames.stick, 2);

		allItemsWithDependencies = ko.computed(function () {
			console.log("computed: allItemsWithDependencies");

			var results: app.types.Item[] = [];

			for (var itemName in app.world.allItems) {

				// just a safety check
				if (!app.world.allItems.hasOwnProperty(itemName)) { continue; }

				// get the actual item
				var item: app.types.Item = app.world.allItems[itemName];

				// make sure its an item that can be built
				if (item.dependencies === null) { continue; }

				results.push(item);
			}

			return results;
		});

		//#region inventoryLookup computed body
		inventoryLookup = ko.computed(function () {
			console.log("computed: inventoryLookup");

			var currentInventory: app.types.InventoryItem[] = inventory();

			var inventoryLookupObject: { [itemName: string]: app.types.InventoryItem; } = {};

			for (var i = 0; i < currentInventory.length; i++) {
				var currentInventoryItem = currentInventory[i];
				inventoryLookupObject[currentInventoryItem.item.name] = currentInventoryItem;
			}

			return inventoryLookupObject;
		});
		//#endregion

		//#region buildableItems computed body
		buildableItems = ko.computed(function () {
			console.log("computed: buildableItems");

			var results: app.types.Item[] = [];

			var itemsWithDependencies: app.types.Item[] = allItemsWithDependencies();

			var inventoryLookupObject: { [itemName: string]: app.types.InventoryItem; } = inventoryLookup();

			for (var i = 0; i < itemsWithDependencies.length; i++) {
				var currentItem = itemsWithDependencies[i];

				if (canBuildItem(currentItem, inventoryLookupObject) === true) {
					console.log("can build", currentItem.name);
					results.push(currentItem);
				}
				else {
					console.log("can't build", currentItem.name);
				}
			}
			return results;
		});
		//#endregion


	};

	export var helloMsg: KnockoutObservableString = ko.observable("");

	export var inventory: KnockoutObservableArray = ko.observableArray([]);

	export var inventoryLookup: KnockoutComputed;

	export var allItemsWithDependencies: KnockoutComputed;

	export var buildableItems: KnockoutComputed;

	var addItemToInventory = function (itemName: string, qty: number) {
		inventory.push(new app.types.InventoryItem(app.world.allItems[itemName], qty));
	};

	var canBuildItem = function (item: app.types.Item, currentInventory: { [itemName: string]: app.types.InventoryItem; }) {

		// we cant build an item without dependencies
		if (item.dependencies === null) { throw "items without dependencies (" + item.name + ") should not be built"; }

		// TODO: see if there are any other preemptive checks that we can perform to return early

		// get the list of items and their quantities that we will need in order to build this item
		var buildListForItem: { [dependencyName: string]: number; } = item.dependencies.getBuildList();

		// go through each item in that list of things we need to build
		for (var requiredItemName in buildListForItem) {

			// safety check
			if (!buildListForItem.hasOwnProperty(requiredItemName)) { continue; }

			var requiredQtyToBuildItem: number = buildListForItem[requiredItemName];

			// if we don't even have a record of that item in our inventory then we cant build it
			if (typeof currentInventory[requiredItemName] === "undefined") {
				return false;
			}

			if (currentInventory[requiredItemName].qty() < requiredQtyToBuildItem) {
				return false;
			}
		}

		return true;
	}




}


$(function () {
	app.init();
});